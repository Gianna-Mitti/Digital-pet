package com.proyecto.DigitalPet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalPetApplicationTests {

	@Test
	void contextLoads() {
	}

}
